// Scroll suave ( links internos )

const menu = document.querySelectorAll('a[href^="#"]');

menu.forEach((item) => {
  item.addEventListener("click", scrollInterno);
});

function scrollInterno(event) {
  event.preventDefault(); // n quero comportamento padrao

  const elemento = event.target;
  const id = elemento.getAttribute("href");
  const section = document.querySelector(id);

  console.log(section);

  window.scroll({
    top: section,
    behavior: "smooth",
  });
}
